# ImageMetaDataRemover
Simple code snippet that remove all meta data from image list
